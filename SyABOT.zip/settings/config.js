const fs = require('fs')

global.nameadmin = "Administrador S&A"
global.owner = "573150560580"
global.group = "120363388452136922" //Mensaje de activacion
global.groupsya = "120363045498321235@g.us" //Mensaje de activacion
global.autorizar = "120363401620631273@g.us" //Mensaje de activacion
global.bot = "573022007582"
global.prefix = "/"
global.nama = "Jesus Malagon"
global.email = "soporteyaportes@gmail.com"
global.namaBot = "SOPORTE Y APORTES BOT"
global.channel = 'https://whatsapp.com/channel/0029VaJDgk3C6ZvjJ7TMxf0w'
global.ytchannel = "UCGEUZ1pmLBa9sJ4lMV97LJw"
global.status = true

global.mess = {
    owner: "no, esto es solo para propietarios",
	group: "esto es solo para grupos",
	private: "esto es específicamente para chat privado"
}

global.packname = 'SOPORTE Y APORTES'
global.author = 'SOPORTE Y APORTES BOT'

//Codigo de emparejamiento (Se puede cambiar pero solo un id de 8 digitos)
global.pairing = "S0P0RTE1"

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
