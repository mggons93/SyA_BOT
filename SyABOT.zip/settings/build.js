{
  "build": "24H2",
  "version": "35.6"
}