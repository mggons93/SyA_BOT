console.clear();
console.log('Iniciando BOT, Espere...');
const system = require("./start/system");

const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    makeInMemoryStore, 
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    generateWAMessage,
    jidDecode, 
    proto, 
    delay,
    relayWAMessage, 
    getContentType, 
    getAggregateVotesInPollMessage, 
    downloadContentFromMessage, 
    fetchLatestWaWebVersion, 
    InteractiveMessage, 
    makeCacheableSignalKeyStore, 
    Browsers, 
    generateForwardMessageContent, 
    MessageRetryMap ,
	BaileysEventMap, 
	WAMessage
} = require("@whiskeysockets/baileys");

const pino = require('pino');
const FileType = require('file-type');
const readline = require("readline");
const fs = require('fs');
const crypto = require("crypto")
const yargs = require('yargs/yargs')
const _ = require('lodash')
const welcomeMessage = require('./start/system.js');
module.exports = welcomeMessage;
const path = require('path')
const dbPath = './database/anticall.json'; // Ajusta el archivo correcto
// Definir la variable global de validaciones pendientes
let pendingValidations = {};
//const GroupDB = "./database/groupcode.json";
const groupDBPath = './database/groupcode.json'; // Ruta del archivo JSON
const globalGroup = global.group; // Grupo donde se enviará el código
const ownerNumber = global.owner; // Número del administrador
const { igdl } = require('./lib/igdl');  // Tu función igdl
const {
    Boom 
} = require('@hapi/boom');

const { 
    color 
} = require('./start/lib/color');
const { TelegraPh } = require('./start/lib/uploader')
const {
    smsg,
    sleep,
    getBuffer
} = require('./start/lib/myfunction');
const { jsonformat } = require('./start/lib/myfunction')
const { 
    imageToWebp,
    videoToWebp,
    writeExifImg,
    writeExifVid,
    addExif
} = require('./start/lib/exif')

var low
try {
  low = require('lowdb')
} catch (e) {
  low = require('./lib/lowdb')
}
const { Low, JSONFile } = low
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
global.db = new Low(
  /https?:\/\//.test(opts['db'] || '') ?
    new cloudDBAdapter(opts['db']) : /mongodb/.test(opts['db']) ?
      new mongoDB(opts['db']) :
      new JSONFile(`./start/database.json`)
)
global.DATABASE = global.db // Backwards Compatibility
global.loadDatabase = async function loadDatabase() {
  if (global.db.READ) return new Promise((resolve) => setInterval(function () { (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null) }, 1 * 1000))
  if (global.db.data !== null) return
  global.db.READ = true
  await global.db.read()
  global.db.READ = false
  global.db.data = {
    users: {},
    chats: {},
    database: {},
    game: {},
    settings: {},
    others: {},
    sticker: {},
    anonymous: {},
    ...(global.db.data || {})
  }
  global.db.chain = _.chain(global.db.data)
}
loadDatabase()

// save database every 30seconds
if (global.db) setInterval(async () => {
    if (global.db.data) await global.db.write()
  }, 30 * 1000)

//////////////////////////////////////////////////////////////
const userFilePath = './database/user.json';
// Función para cargar usuarios desde el archivo
const loadUsers = () => {
    if (!fs.existsSync(userFilePath)) {
        fs.writeFileSync(userFilePath, JSON.stringify({}, null, 2)); // Crear archivo vacío si no existe
    }
    return JSON.parse(fs.readFileSync(userFilePath, 'utf8'));
};

// Función para guardar usuarios en el archivo
const saveUsers = (users) => {
    fs.writeFileSync(userFilePath, JSON.stringify(users, null, 2));
};

// Función para agregar un usuario si no está registrado
const addUser = (groupId, userId) => {
    let users = loadUsers();
    const currentTime = new Date().toLocaleString();

    if (!users[groupId]) {
        users[groupId] = {}; // Si el grupo no existe, lo crea
    }

    if (!users[groupId][userId]) {
        users[groupId][userId] = {
            mensajes: 0,
            ultimaHora: currentTime
        };
        saveUsers(users);
        console.log(`Usuario ${userId} agregado correctamente en el grupo ${groupId}.`);
    } else {
        console.log(`Usuario ${userId} ya está registrado en el grupo ${groupId}.`);
    }
};

// Función para cargar la base de datos
const loadDB = () => {
    if (!fs.existsSync(dbPath)) {
        fs.writeFileSync(dbPath, JSON.stringify({ data: { settings: {} } }, null, 2));
    }
    return JSON.parse(fs.readFileSync(dbPath, 'utf8'));
};

// Cargar la base de datos
let db = loadDB();

const usePairingCode = true;

const question = (text) => {
    const rl = readline.createInterface({ 
        input: process.stdin, 
        output: process.stdout 
    });
    return new Promise((resolve) => { rl.question(text, resolve) });
}

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });


async function clientstart() {
	const {
		state,
		saveCreds
	} = await useMultiFileAuthState("session")
	const client = makeWASocket({
		printQRInTerminal: !usePairingCode,
		syncFullHistory: true,
		markOnlineOnConnect: true,
		connectTimeoutMs: 60000,
		defaultQueryTimeoutMs: 0,
		keepAliveIntervalMs: 10000,
		generateHighQualityLinkPreview: true,
		patchMessageBeforeSending: (message) => {
			const requiresPatch = !!(
				message.buttonsMessage ||
				message.templateMessage ||
				message.listMessage
			);
			if (requiresPatch) {
				message = {
					viewOnceMessage: {
						message: {
							messageContextInfo: {
								deviceListMetadataVersion: 2,
								deviceListMetadata: {},
							},
							...message,
						},
					},
				};
			}

			return message;
		},
		version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
		browser: ["Windows", "Chrome", "20.0.04"],
		logger: pino({
			level: 'fatal'
		}),
		auth: {
			creds: state.creds,
			keys: makeCacheableSignalKeyStore(state.keys, pino().child({
				level: 'silent',
				stream: 'store'
			})),
		}
	});


    if (usePairingCode && !client.authState.creds.registered) {
        const phoneNumber = await question('Por favor ingrese su número de WhatsApp, comenzando con el codigo de pais:\n');
        const code = await client.requestPairingCode(phoneNumber,global.pairing);
        console.log(`Tu código de emparejamiento es: ${code}`);
    }

    store.bind(client.ev);
    
    client.ev.on("messages.upsert", async (chatUpdate, msg) => {
        try {
            const mek = chatUpdate.messages[0]
            if (!mek.message) return
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
            if (mek.key && mek.key.remoteJid === 'status@broadcast') return
            if (!client.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
            if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
            if (mek.key.id.startsWith('FatihArridho_')) return;
            const m = smsg(client, mek, store)
            require("./start/system")(client, m, chatUpdate, store)
        } catch (err) {
            console.log(err)
        }
    });

    client.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    client.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = client.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = {
                id,
                name: contact.notify
            };
        }
    });

    client.public = global.status

/////////////////////////////////////////////////////////////////////	
/////////////////////////////////////////////////////////////////////

    client.sendText = async (jid, text, quoted = '', options) => {
        client.sendMessage(jid, {
            text: text,
            ...options
        },{ quoted });
    }
////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////	
client.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'open') {
        console.log('✅ Bot en línea');

        let mensaje = `🔹 *Soporte y Aportes BOT* 🔹\n\n✅ *El servidor está en línea y operativo.*\n\n📅 Fecha: ${new Date().toLocaleString()}`;

        try {
            // Enviar mensaje al grupo de soporte
            await client.sendMessage(globalGroup + '@g.us', { text: mensaje });
            console.log(`📩 Notificación enviada al grupo: ${globalGroup}`);
        } catch (error) {
            console.error('❌ Error al enviar los mensajes:', error);
        }

        // 📌 Registrar automáticamente los grupos en los que ya está el bot
        await registrarGruposBot();
    } else if (connection === 'close') {
        console.log('❌ Conexión cerrada');

        if (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut) {
            console.log('🔄 Sistema identificado, Reiniciando...');
            clientstart(); // Reintentar conexión si no es un cierre no autorizado
        }
    }
    console.log(update); // Muestra la actualización en la consola para depuración
});

// 📌 Función para verificar si el grupo está registrado
function verificarGrupo(groupId) {
    try {
        if (fs.existsSync(groupDBPath)) {
            let groupData = JSON.parse(fs.readFileSync(groupDBPath, "utf-8"));
            if (groupData[groupId]) {
                return {
                    isAdmin: groupData[groupId].isAdmin || false,
                    validated: groupData[groupId].validated || false,
                    activationCode: groupData[groupId].activationCode || null
                };
            }
        }
    } catch (error) {
        console.error("❌ Error al leer el archivo groupcode.json:", error);
    }
    return { isAdmin: false, validated: false, activationCode: null };
}

// 📌 Función para registrar un nuevo grupo y generar código de activación
function registrarGrupo(groupId, groupName, validated = false) {
    let groupData = {};

    if (fs.existsSync(groupDBPath)) {
        groupData = JSON.parse(fs.readFileSync(groupDBPath, "utf-8"));
    }

    const activationCode = crypto.randomBytes(4).toString("hex").toUpperCase();

    groupData[groupId] = {
        groupName: groupName || "Grupo Desconocido",
        isAdmin: false,
        validated: validated,
        activationCode: activationCode,
		bloqueado: false,
        attempts: 0
    };

    fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");
    return activationCode;
}

// ✅ Función para registrar automáticamente grupos en los que ya está el bot
async function registrarGruposBot() {
    try {
        const grupos = await client.groupFetchAllParticipating();
        let groupData = fs.existsSync(groupDBPath) ? JSON.parse(fs.readFileSync(groupDBPath, "utf-8")) : {};

        for (let groupId in grupos) {
            let groupName = grupos[groupId].subject || "Grupo Desconocido";

            try {
                // 📌 Verificar si el bot es administrador en el grupo
                let groupMetadata = await client.groupMetadata(groupId);
                let botNumber = client.user.id.split(":")[0] + "@s.whatsapp.net";
                let isAdmin = !!groupMetadata.participants.find(p => p.id === botNumber && p.admin);

                if (groupData[groupId]) {
                    // 📌 Solo actualiza isAdmin sin modificar validated
                    groupData[groupId].isAdmin = isAdmin;
                } else {
                    // 📌 Si el grupo no está registrado, lo añade con validated en false
                    groupData[groupId] = {
                        groupName: groupName,
                        isAdmin: isAdmin,
                        validated: false, // ✅ No se cambia a true, se mantiene en false hasta validación
                        activationCode: crypto.randomBytes(4).toString("hex").toUpperCase(),
						bloqueado: false,
                        attempts: 0
                    };
                }

                // 📌 Guardar solo si hubo cambios
                fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");
                console.log(`✅ Grupo registrado/actualizado: ${groupName} (Admin: ${isAdmin})`);

            } catch (error) {
                console.error(`❌ Error al verificar admin en ${groupName}:`, error);
            }
        }
    } catch (error) {
        console.error("❌ Error al registrar automáticamente los grupos:", error);
    }
}

client.ev.on('messages.upsert', async (chatUpdate) => {
    try {
        let m = chatUpdate.messages[0]; // Obtener el primer mensaje recibido
        if (!m.message || m.key.fromMe) return; // Ignorar mensajes vacíos o enviados por el bot

        let messageType = Object.keys(m.message)[0]; // Obtener el tipo de mensaje

        if (messageType === "stickerMessage") {
            let sender = m.key.remoteJid; // Número del remitente
            console.log(`📩 Sticker recibido de: ${sender}`);

            // Enviar una reacción al sticker
            await client.sendMessage(sender, {
                react: { text: "✅", key: m.key } // Puedes cambiar el emoji
            });
        }
    } catch (error) {
        console.error("❌ Error al responder al sticker:", error);
    }
});

// Evento de detección de nuevos miembros
client.ev.on('group-participants.update', async (anu) => {
    console.log(anu);
    try {
        let metadata = await client.groupMetadata(anu.id);
        let participants = anu.participants;

        // Ruta del JSON de validación
        let groupData = fs.existsSync(groupDBPath) ? JSON.parse(fs.readFileSync(groupDBPath, 'utf-8')) : {};

        // Ruta del JSON de reglas
        const reglasPath = path.join(__dirname, './database/reglas.json');
        let reglasTexto = "📜 *No hay reglas disponibles.*"; 

        if (fs.existsSync(reglasPath)) {
            try {
                let reglasData = JSON.parse(fs.readFileSync(reglasPath, 'utf8'));
                if (reglasData.reglas && Array.isArray(reglasData.reglas)) {
                    reglasTexto = reglasData.reglas.map((regla) => `${regla}`).join("\n");
                }
            } catch (error) {
                console.error("Error al leer el archivo reglas.json:", error);
            }
        } else {
            console.warn("⚠️ El archivo reglas.json no existe.");
        }

        for (let num of participants) {
            addUser(anu.id, num);

            let ppuser;
            try {
                ppuser = await client.profilePictureUrl(num, 'image');
            } catch {
                ppuser = 'https://tinyurl.com/yx93l6da';
            }

            if (anu.action == 'add') {
                await client.sendMessage(anu.id, { 
                    image: { url: ppuser }, 
                    mentions: [num], 
                    caption: `👋 *Bienvenid@ a ${metadata.subject}*\n\n📌 *Usuario:* @${num.split("@")[0]}\n\n${reglasTexto}\n\n🚀 ¡Esperamos que disfrutes tu estancia en el grupo!\n🔹 *Si tienes dudas, contacta a un administrador.*`
                });
            } else if (anu.action == 'remove') {
                await client.sendMessage(anu.id, { 
                    image: { url: ppuser }, 
                    mentions: [num], 
                    caption: `@${num.split("@")[0]} ha sido eliminado del grupo.`
                });
            } else if (anu.action == 'promote') {
                // ✅ Actualiza validación cuando alguien es promovido
                if (groupData[anu.id]) {
                    groupData[anu.id].isAdmin = true;
                    fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");
                }

                await client.sendMessage(anu.id, { 
                    image: { url: ppuser }, 
                    mentions: [num], 
                    caption: `@${num.split('@')[0]} ha sido promovido en ${metadata.subject}.*`
                });
            } else if (anu.action == 'demote') {
                // ❌ Revoca validación cuando alguien es degradado
                if (groupData[anu.id]) {
                    groupData[anu.id].isAdmin = false;
                    fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");
                }

                await client.sendMessage(anu.id, { 
                    image: { url: ppuser }, 
                    mentions: [num], 
                    caption: `@${num.split('@')[0]} ha sido degradado en ${metadata.subject}.*`
                });
            }
        }
    } catch (err) {
        console.log("Error en la gestión de participantes:", err);
    }
});

// Manejo del mensaje (Evita que el bot se active varias veces en un mismo mensaje)
// Verifica grupo
// 📌 Función para verificar si el grupo está validado y si el bot es admin
function verificarGrupo(groupId) {
    try {
        if (fs.existsSync(groupDBPath)) {
            let groupData = JSON.parse(fs.readFileSync(groupDBPath, "utf-8"));
            if (groupData[groupId]) {
                return {
                    isAdmin: groupData[groupId].isAdmin || false, // Si no está definido, asumimos false
                    validated: groupData[groupId].validated || false // Si no está definido, asumimos false
                };
            }
        }
    } catch (error) {
        console.error("❌ Error al leer el archivo groupcode.json:", error);
    }
    return { isAdmin: false, validated: false }; // Por defecto, no es admin y no está validado
}
		
// 📌 Función para verificar si el grupo está registrado
function verificarGrupo(groupId) {
			try {
				if (fs.existsSync(groupDBPath)) {
					let groupData = JSON.parse(fs.readFileSync(groupDBPath, "utf-8"));
					if (groupData[groupId]) {
						return {
							isAdmin: groupData[groupId].isAdmin || false,
							validated: groupData[groupId].validated || false,
							activationCode: groupData[groupId].activationCode || null
						};
					}
				}
			} catch (error) {
				console.error("❌ Error al leer el archivo groupcode.json:", error);
			}
			return { isAdmin: false, validated: false, activationCode: null };
}

		// 📌 Función para registrar un nuevo grupo y generar código de activación
function registrarGrupo(groupId, groupName) {
			let groupData = {};

			if (fs.existsSync(groupDBPath)) {
				groupData = JSON.parse(fs.readFileSync(groupDBPath, "utf-8"));
			}

			// Generar un código hash de 8 caracteres alfanuméricos
			const activationCode = crypto.randomBytes(4).toString("hex").toUpperCase();

			// Registrar el grupo con `validated: false` y `isAdmin: false`
			groupData[groupId] = {
				groupName: groupName || "Grupo Desconocido",
				isAdmin: false,
				validated: false,
				activationCode: activationCode,
				activationTime: currentTime,
				bloqueado: false,
				attempts: 0 // Contador de intentos fallidos
			};

			fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");

			return activationCode;
}

function generarNuevoCodigo() {
    return Math.random().toString(36).substr(2, 8).toUpperCase();
}

client.ev.on("messages.upsert", async (chatUpdate) => {
    try {
        const message = chatUpdate.messages[0];
        if (!message || !message.key || message.key.fromMe) return;

        const groupId = message.key.remoteJid;
        if (!groupId || !groupId.includes("@g.us")) return;

        let groupMetadata;
        try {
            groupMetadata = await client.groupMetadata(groupId);
            if (!groupMetadata) throw new Error("No se pudo obtener la metadata del grupo.");
        } catch (error) {
            console.error("❌ Error al obtener metadata del grupo:", error);
            return;
        }

        const groupName = groupMetadata.subject || "Grupo Desconocido";
        const body = message.message?.conversation || message.message?.extendedTextMessage?.text || "";

        let groupData = JSON.parse(fs.readFileSync(groupDBPath, "utf-8"));
        let groupInfo = groupData[groupId] || null;

        const currentTime = Date.now();

        // No responde si no contiene prefix "/autorizar" ni "/codigo"
        if (!body.startsWith("/autorizar" , "/Autorizar") && !body.startsWith("/codigo" , "/Codigo")) return;

        // Si el mensaje es "/autorizar"
        if (body.startsWith("/autorizar", "/Autorizar")) {
            if (groupInfo && groupInfo.validated) {
                await client.sendMessage(groupId, { text: "✅ *Este grupo ya está autorizado.*" })
                    .catch(err => console.error("❌ Error enviando mensaje de autorización repetida:", err));
                return;
            }

            let activationCode = generarNuevoCodigo();
            groupData[groupId] = {
                groupName,
                isAdmin: groupData[groupId]?.isAdmin ?? false, // Mantiene el estado actual si ya existe
                validated: false,
                activationCode,
                activationTime: currentTime,
                attempts: 0
            };
            fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");

            let adminMensaje = `🔐 *Solicitud de autorización.*\n📌 *Grupo:* ${groupName}\n🔑 *Código:* ${activationCode}`;
            if (global.autorizar) {
                await client.sendMessage(global.autorizar, { text: adminMensaje })
                    .catch(err => console.error("❌ Error enviando mensaje a admin:", err));
            }

            let groupMensaje = `🔐 *Solicitud enviada.*\n📌 *Grupo:* ${groupName}\n📞 *Espere confirmación.*`;
            await client.sendMessage(groupId, { text: groupMensaje })
                .catch(err => console.error("❌ Error enviando mensaje al grupo:", err));
            return;
        }

        // Si no existe la información del grupo, crea una nueva
        if (!groupInfo) {
            let activationCode = generarNuevoCodigo();
            groupData[groupId] = {
                groupName,
                isAdmin: false,
                validated: false,
                activationCode,
                activationTime: currentTime,
				bloqueado: false,
                attempts: 0
            };
            fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");

            let notifyAdmin = `Bot SyA: 🔐 Grupo no validado.\n🔑 Código: ${activationCode}\n✍️ Envíe /codigo <código> para validar.`;
            if (global.autorizar) {
                await client.sendMessage(global.autorizar, { text: notifyAdmin })
                    .catch(err => console.error("❌ Error enviando mensaje a grupo de autorizaciones:", err));
            }
            return;
        }

       
        // Si el mensaje es "/codigo"
		if (body.startsWith("/codigo" , "/Codigo")) {
		let userCode = body.replace(/^\/codigo\s+/i, "").trim();

		console.log(`🔍 Verificando código. Código recibido: ${userCode}`);

		if (userCode === groupInfo.activationCode) {
			console.log(`✅ Código correcto. Procediendo con la validación del grupo.`);

        // Respuesta con el código y validación
        await client.sendMessage(groupId, { text: `/codigo ${userCode} acepte la validación del grupo` })
            .catch(err => console.error("❌ Error enviando mensaje de validación:", err));

        // ✅ Se autoriza el grupo siempre, sin importar si el código es correcto o no
        groupInfo.validated = true;
        groupInfo.attempts = 0;

        // Guardar el estado actualizado del grupo
        fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");
        console.log(`📁 Estado del grupo actualizado. El grupo ha sido validado.`);

        await client.sendMessage(groupId, { text: "✅ *Grupo validado exitosamente.*" })
            .catch(err => console.error("❌ Error enviando mensaje de validación:", err));

        // 🔄 Refrescar la lista de administradores después de la validación
        try {
            groupMetadata = await client.groupMetadata(groupId);
            groupData[groupId].admins = groupMetadata.participants
                .filter(p => p.admin)
                .map(p => p.id);
            fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");

            console.log(`👥 Lista de administradores actualizada correctamente para el grupo ${groupName}.`);
        } catch (error) {
            console.error("❌ Error al actualizar la lista de administradores:", error);
        }

			} else {
				console.log(`⚠️ Código incorrecto. Código recibido: ${userCode}`);

				let validCodes = Object.values(groupData).map(info => info.activationCode);
				if (validCodes.includes(userCode)) {
					console.log(`⚠️ El código recibido pertenece a otro grupo. Código no válido para este grupo.`);

					await client.sendMessage(groupId, { text: "⚠️ *El código ingresado pertenece a otro grupo. Verifique el código correcto.*" })
						.catch(err => console.error("❌ Error enviando mensaje de código incorrecto de otro grupo:", err));
				} else {
					console.log(`⚠️ Código incorrecto. Intentos restantes: ${5 - groupInfo.attempts}`);

					groupInfo.attempts = (groupInfo.attempts || 0) + 1;
					fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");

					await client.sendMessage(groupId, { text: `⚠️ *Código incorrecto.* Intentos restantes: ${5 - groupInfo.attempts}` })
						.catch(err => console.error("❌ Error enviando mensaje de intento fallido:", err));
				}
			}
			return;
		}

	 // Si el grupo no está validado
        if (!groupInfo.validated) {
            if ((currentTime - groupInfo.activationTime) > 300000) { // 5 minutos
                groupInfo.activationCode = generarNuevoCodigo();
                groupInfo.activationTime = currentTime;
                fs.writeFileSync(groupDBPath, JSON.stringify(groupData, null, 2), "utf-8");
            }

            if (!body.startsWith("/codigo" , "/Codigo")) {
                let noAuthMessage = `🔒 Este grupo no está validado.\n📞 Contacte al administrador: wa.me/573150560580`;
                await client.sendMessage(groupId, { text: noAuthMessage })
                    .catch(err => console.error("❌ Error enviando mensaje de grupo no autorizado:", err));

                let notifyAdmin = `Bot SyA: 🔐 Grupo no validado.\n🔑 Código: ${groupInfo.activationCode}\n✍️ Envíe /codigo <código> para validar.`;
                if (global.autorizar) {
                    await client.sendMessage(global.autorizar, { text: notifyAdmin })
                        .catch(err => console.error("❌ Error enviando mensaje a grupo de autorizaciones:", err));
                }
            }
            return;
        }


    } catch (error) {
        console.error("❌ Error en el procesamiento del mensaje:", error);
    }
});



// Verificar si el bot está en un grupo bloqueado y salir automáticamente si lo reintegran
client.ev.on("group-participants.update", async (update) => {
    try {
        const { id, participants, action } = update;

        if (action === "add" && participants.includes(client.user.id)) {
            let groupData = JSON.parse(fs.readFileSync(groupDBPath, "utf-8"));
            if (groupData[id]?.blocked) {
                await client.sendMessage(id, { text: "🚫 *Este grupo ha sido bloqueado.* El bot no puede reintegrarse." })
                    .catch(err => console.error("❌ Error enviando mensaje de bloqueo:", err));

                await client.groupLeave(id).catch(err => console.error("❌ Error al salir del grupo bloqueado:", err));
            }
        }
    } catch (error) {
        console.error("❌ Error en la detección de reintegro del bot:", error);
    }
});


// Esperar respuesta del owner
    client.ev.on('message', async (respuesta) => {
        if (respuesta.key.remoteJid !== groupId || respuesta.sender !== owner + "@s.whatsapp.net") return;
        
        let confirmacion = respuesta.message.conversation.toLowerCase();

        if (confirmacion === 'no') {
            await client.sendMessage(groupId, { text: "🚫 Eliminación cancelada por el owner." });
            return;
        }

        if (confirmacion !== 'sí') return;

        for (let i = 0; i < candidatosEliminar.length; i++) {
            setTimeout(async () => {
                let userToRemove = candidatosEliminar[i] + "@s.whatsapp.net";

                try {
                    await client.groupParticipantsUpdate(groupId, [userToRemove], "remove");

                    await client.sendMessage(userToRemove, {
                        text: "⚠️ Se te eliminó del grupo por inactividad o ausencia. Si consideras que esto fue un error, contacta al administrador global."
                    });

                } catch (error) {
                    console.error(`❌ Error al eliminar ${userToRemove}:`, error);

                    await client.sendMessage(global.owner + "@s.whatsapp.net", {
                        text: `🚨 Error al eliminar a @${candidatosEliminar[i]} en el grupo ${groupId}.\n\nDetalles del error: ${error.message}`,
                        mentions: [global.owner + "@s.whatsapp.net"]
                    });
                }
            }, i * 500000);
        }
    });	
	
	
///////////////////////////////////////////////////////
// Manejo de la respuesta cuando el usuario elige una opción
client.ev.on("messages.upsert", async ({ messages }) => {
    let msg = messages[0];
    if (!msg.message || !msg.key.remoteJid) return;

    // Verificar si el mensaje es una respuesta de lista
    if (msg.message.listResponseMessage) {
        let selectedRowId = msg.message.listResponseMessage.singleSelectReply.selectedRowId;

        if (selectedRowId === "descargar_audio") {
            await client.sendMessage(msg.key.remoteJid, { text: `🎵 Aquí tienes el enlace de descarga del audio:\n${crot}` });
        } else if (selectedRowId === "descargar_video") {
            await client.sendMessage(msg.key.remoteJid, { text: `📹 Aquí tienes el enlace de descarga del video:\n${videoUrl}` });
        }
    }
});

// Manejo de respuesta del usuario a los botones
client.ev.on("messages.upsert", async ({ messages }) => {
    let msg = messages[0];
    if (!msg.message || !msg.key.remoteJid) return;

    // Verificar si el usuario hizo clic en un botón
    if (msg.message.buttonsResponseMessage) {
        let buttonId = msg.message.buttonsResponseMessage.selectedButtonId;

        if (buttonId.startsWith("descargar_audio_")) {
            let audioUrl = buttonId.replace("descargar_audio_", "");
            await client.sendMessage(msg.key.remoteJid, { text: `🎵 Aquí tienes el enlace de descarga del audio:\n${audioUrl}` });
        } else if (buttonId.startsWith("descargar_video_")) {
            let videoUrl = buttonId.replace("descargar_video_", "");
            await client.sendMessage(msg.key.remoteJid, { text: `📹 Aquí tienes el enlace de descarga del video:\n${videoUrl}` });
        }
    }
});


    client.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(message, messageType)
        let buffer = Buffer.from([])
        for await(const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])}
        return buffer
    }

    client.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? 
            path : /^data:.*?\/.*?;base64,/i.test(path) ?
            Buffer.from(path.split`, `[1], 'base64') : /^https?:\/\//.test(path) ?
            await (await getBuffer(path)) : fs.existsSync(path) ? 
            fs.readFileSync(path) : Buffer.alloc(0);
        
        let buffer;
        if (options && (options.packname || options.author)) {
            buffer = await writeExifImg(buff, options);
        } else {
            buffer = await addExif(buff);
        }
        
        await client.sendMessage(jid, { 
            sticker: { url: buffer }, 
            ...options }, { quoted });
        return buffer;
    };
    
    client.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || "";
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, "") : mime.split("/")[0];

        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? filename + "." + type.ext : filename;
        await fs.writeFileSync(trueFileName, buffer);
        
        return trueFileName;
    };


    client.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? 
            path : /^data:.*?\/.*?;base64,/i.test(path) ?
            Buffer.from(path.split`, `[1], 'base64') : /^https?:\/\//.test(path) ?
            await (await getBuffer(path)) : fs.existsSync(path) ? 
            fs.readFileSync(path) : Buffer.alloc(0);

        let buffer;
        if (options && (options.packname || options.author)) {
            buffer = await writeExifVid(buff, options);
        } else {
            buffer = await videoToWebp(buff);
        }

        await client.sendMessage(jid, {
            sticker: { url: buffer }, 
            ...options }, { quoted });
        return buffer;
    };

    client.albumMessage = async (jid, array, quoted) => {
        const album = generateWAMessageFromContent(jid, {
            messageContextInfo: {
                messageSecret: crypto.randomBytes(32),
            },
            
            albumMessage: {
                expectedImageCount: array.filter((a) => a.hasOwnProperty("image")).length,
                expectedVideoCount: array.filter((a) => a.hasOwnProperty("video")).length,
            },
        }, {
            userJid: client.user.jid,
            quoted,
            upload: client.waUploadToServer
        });

        await client.relayMessage(jid, album.message, {
            messageId: album.key.id,
        });

        for (let content of array) {
            const img = await generateWAMessage(jid, content, {
                upload: client.waUploadToServer,
            });

            img.message.messageContextInfo = {
                messageSecret: crypto.randomBytes(32),
                messageAssociation: {
                    associationType: 1,
                    parentMessageKey: album.key,
                },    
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                forwardingScore: 99999,
                isForwarded: true,
                mentionedJid: [jid],
                starred: true,
                labels: ["Y", "Important"],
                isHighlighted: true,
                businessMessageForwardInfo: {
                    businessOwnerJid: jid,
                },
                dataSharingContext: {
                    showMmDisclosure: true,
                },
            };

            img.message.forwardedNewsletterMessageInfo = {
                newsletterJid: "0@newsletter",
                serverMessageId: 1,
                newsletterName: `WhatsApp`,
                contentType: 1,
                timestamp: new Date().toISOString(),
                senderName: "✧ Tu sentido",
                content: "Text Message",
                priority: "high",
                status: "sent",
            };

            img.message.disappearingMode = {
                initiator: 3,
                trigger: 4,
                initiatorDeviceJid: jid,
                initiatedByExternalService: true,
                initiatedByUserDevice: true,
                initiatedBySystem: true,
                initiatedByServer: true,
                initiatedByAdmin: true,
                initiatedByUser: true,
                initiatedByApp: true,
                initiatedByBot: true,
                initiatedByMe: true,
            };

            await client.relayMessage(jid, img.message, {
                messageId: img.key.id,
                quoted: {
                    key: {
                        remoteJid: album.key.remoteJid,
                        id: album.key.id,
                        fromMe: true,
                        participant: client.user.jid,
                    },
                    message: album.message,
                },
            });
        }
        return album;
    };
    
    client.sendStatusMention = async (content, jids = []) => {
        let users;
        for (let id of jids) {
            let userId = await client.groupMetadata(id);
            users = await userId.participants.map(u => client.decodeJid(u.id));
        };

        let message = await client.sendMessage(
            "status@broadcast", content, {
                backgroundColor: "#000000",
                font: Math.floor(Math.random() * 9),
                statusJidList: users,
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: jids.map((jid) => ({
                                    tag: "to",
                                    attrs: { jid },
                                    content: undefined,
                                })),
                            },
                        ],
                    },
                ],
            }
        );

        jids.forEach(id => {
            client.relayMessage(id, {
                groupStatusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: message.key,
                            type: 25,
                        },
                    },
                },
            },
            {
                userJid: client.user.jid,
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "true" },
                        content: undefined,
                    },
                ],
            });
            delay(2500);
        });
        return message;
    };
    client.ev.on('creds.update', saveCreds);
    return client;
}
clientstart();

module.exports = { clientstart }; // ✅ Exportar clientstart
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
