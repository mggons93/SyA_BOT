#!bin/bash
printf '\e[12;50;85t'  # Cambia el tamaño de la terminal a 30 filas y 100 columnas
GREEN='\033[0;32m'
while : 
do
echo ""
    node .
    sleep 1

done
